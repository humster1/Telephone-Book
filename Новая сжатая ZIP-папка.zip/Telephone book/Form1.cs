using System.Drawing.Drawing2D;
using System.Text.RegularExpressions;

namespace Telephone_book
{
    public partial class Form1 : Form
    {
        private ContactManager contactManager;

        public Form1()
        {
            InitializeComponent();
            contactManager = new ContactManager();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GraphicsPath buttonPath = new GraphicsPath();
            buttonPath.AddEllipse(0, 0, button1.Width, button1.Height);
            button1.Region = new Region(buttonPath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button7.Visible = false;
            label2.Text = "����� ��������";
            label3.Visible = true;
            label2.Visible = true;
            textBox1.Visible = true;
            button8.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            contactManager.LoadContacts("numbers.txt");
            listBox1.Items.Clear();
            listBox1.Items.AddRange(contactManager.GetContacts());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (MessageBox.Show("�� ������ ������� ���� �������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    contactManager.RemoveContact(listBox1.SelectedIndex);
                    listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                }
            }
            else
            {
                MessageBox.Show("�� ������ �������!", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�� ������ ��������� ��������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                contactManager.SaveContacts("numbers.txt");
                MessageBox.Show("�������� ������� ���������!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�� ������ ��������� ������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button8.Visible = false;
            label2.Text = "�������� ����� �������";
            label2.Visible = true;
            button7.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            string phoneNumber = textBox2.Text;

            if (contactManager.ValidateContact(firstName, phoneNumber))
            {
                contactManager.AddContact(firstName, phoneNumber);
                listBox1.Items.Add(contactManager.GetFormattedContact(firstName, phoneNumber));

                listBox1.Sorted = true;

                if (MessageBox.Show("������� ��������! ������ ���������� ����������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    textBox1.Text = null;
                    textBox2.Text = null;
                }
                else
                {
                    ResetAddContactUI();
                }
            }
            else
            {
                MessageBox.Show("��������� ������������ �����!", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string searchName = textBox1.Text;
            int index = contactManager.FindContactIndex(searchName);

            if (index != -1)
            {
                listBox1.SelectedIndex = index;
            }
            else
            {
                MessageBox.Show("������� �� ������!", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Thread.Sleep(1000);
            ResetSearchUI();
        }

        private void ResetAddContactUI()
        {
            label2.Text = "������!";
            label2.Visible = false;
            button7.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
        }

        private void ResetSearchUI()
        {
            label2.Text = "������!";
            label3.Visible = false;
            label2.Visible = false;
            textBox1.Visible = false;
            button8.Visible = false;
        }
    }

    public class ContactManager
    {
        private List<string> contacts;

        public ContactManager()
        {
            contacts = new List<string>();
        }

        public void LoadContacts(string filePath)
        {
            contacts.Clear();

            if (File.Exists(filePath))
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        contacts.Add(line);
                    }
                }
            }
        }

        public void SaveContacts(string filePath)
        {
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                foreach (string contact in contacts)
                {
                    sw.WriteLine(contact);
                }
            }
        }

        public void AddContact(string firstName, string phoneNumber)
        {
            string formattedContact = GetFormattedContact(firstName, phoneNumber);
            contacts.Add(formattedContact);
        }

        public void RemoveContact(int index)
        {
            if (index >= 0 && index < contacts.Count)
            {
                contacts.RemoveAt(index);
            }
        }

        public int FindContactIndex(string searchName)
        {
            return contacts.FindIndex(c => c.Contains(searchName));
        }

        public string[] GetContacts()
        {
            return contacts.ToArray();
        }

        public bool ValidateContact(string firstName, string phoneNumber)
        {
            bool isNameValid = Regex.IsMatch(firstName, @"^[�-��-�]+$");
            bool isPhoneValid = Regex.IsMatch(phoneNumber, @"^[0-9]{11}$");

            return isNameValid && isPhoneValid;
        }

        public string GetFormattedContact(string firstName, string phoneNumber)
        {
            string formattedPhoneNumber = FormatPhoneNumber(phoneNumber);
            return $"{firstName} {formattedPhoneNumber}";
        }

        private string FormatPhoneNumber(string phoneNumber)
        {
            string digitsOnly = new string(phoneNumber.Where(c => char.IsDigit(c)).SkipWhile(c => c == '7').ToArray());
            return digitsOnly.Insert(0, "(").Insert(4, ")").Insert(8, "-").Insert(11, "-");
        }
    }
}
