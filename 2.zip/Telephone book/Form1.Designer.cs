﻿namespace Telephone_book
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            listBox1 = new ListBox();
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            button7 = new Button();
            button8 = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(12, 45);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(272, 334);
            listBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.Transparent;
            button1.Location = new Point(60, 397);
            button1.Name = "button1";
            button1.Size = new Size(163, 38);
            button1.TabIndex = 1;
            button1.Text = "Показать контакты";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Constantia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(69, 9);
            label1.Name = "label1";
            label1.Size = new Size(117, 23);
            label1.TabIndex = 2;
            label1.Text = "Контакты";
            // 
            // button2
            // 
            button2.BackColor = Color.Coral;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.Transparent;
            button2.Location = new Point(309, 45);
            button2.Name = "button2";
            button2.Size = new Size(172, 34);
            button2.TabIndex = 3;
            button2.Text = "Поиск контактов";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Coral;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.Transparent;
            button3.Location = new Point(309, 107);
            button3.Name = "button3";
            button3.Size = new Size(172, 32);
            button3.TabIndex = 4;
            button3.Text = "Добавить контакт";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Coral;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.Transparent;
            button4.Location = new Point(309, 168);
            button4.Name = "button4";
            button4.Size = new Size(172, 32);
            button4.TabIndex = 5;
            button4.Text = "Удалить контакт";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Coral;
            button5.FlatStyle = FlatStyle.Popup;
            button5.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button5.ForeColor = Color.Transparent;
            button5.Location = new Point(309, 237);
            button5.Name = "button5";
            button5.Size = new Size(172, 32);
            button5.TabIndex = 6;
            button5.Text = "Сохранить контакты";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Coral;
            button6.FlatStyle = FlatStyle.Popup;
            button6.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button6.ForeColor = Color.Transparent;
            button6.Location = new Point(309, 296);
            button6.Name = "button6";
            button6.Size = new Size(172, 32);
            button6.TabIndex = 7;
            button6.Text = "Закрыть программу";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Constantia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(534, 50);
            label2.Name = "label2";
            label2.Size = new Size(92, 23);
            label2.TabIndex = 8;
            label2.Text = "Привет!";
            label2.Visible = false;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Constantia", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.Location = new Point(588, 129);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(158, 23);
            textBox1.TabIndex = 9;
            textBox1.Visible = false;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Constantia", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            textBox2.Location = new Point(588, 221);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(158, 23);
            textBox2.TabIndex = 10;
            textBox2.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Constantia", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.ForeColor = Color.Transparent;
            label3.Location = new Point(556, 107);
            label3.Name = "label3";
            label3.Size = new Size(241, 19);
            label3.TabIndex = 11;
            label3.Text = "Введите имя и/или фамилию";
            label3.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Constantia", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.ForeColor = Color.Transparent;
            label4.Location = new Point(588, 199);
            label4.Name = "label4";
            label4.Size = new Size(152, 19);
            label4.TabIndex = 12;
            label4.Text = "Введите телефон";
            label4.Visible = false;
            // 
            // button7
            // 
            button7.BackColor = Color.Red;
            button7.FlatStyle = FlatStyle.Popup;
            button7.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button7.ForeColor = Color.Transparent;
            button7.Location = new Point(611, 267);
            button7.Name = "button7";
            button7.Size = new Size(118, 29);
            button7.TabIndex = 13;
            button7.Text = "Добавить";
            button7.UseVisualStyleBackColor = false;
            button7.Visible = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.Red;
            button8.FlatStyle = FlatStyle.Popup;
            button8.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button8.ForeColor = Color.Transparent;
            button8.Location = new Point(611, 158);
            button8.Name = "button8";
            button8.Size = new Size(95, 29);
            button8.TabIndex = 14;
            button8.Text = "Поиск";
            button8.UseVisualStyleBackColor = false;
            button8.Visible = false;
            button8.Click += button8_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(796, 611);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Name = "Form1";
            Text = "Telephone Book";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Button button1;
        private Label label1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private Label label4;
        private Button button7;
        private Button button8;
    }
}