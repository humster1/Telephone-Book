using System.Drawing.Drawing2D;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Telephone_book
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GraphicsPath buttonPath = new GraphicsPath();
            buttonPath.AddEllipse(0, 0, button1.Width, button1.Height);
            button1.Region = new Region(buttonPath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "����� ��������"; label3.Visible = true; label2.Visible = true; textBox1.Visible = true;
            button8.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(@"numbers.txt", true);


            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();

                listBox1.Items.Add(line);
            }
            sr.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (MessageBox.Show("�� ������ ������� ���� �������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                }
                else
                {
                    return;
                }

            }
            else
            {
                MessageBox.Show("�� ������ �������!", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�� ������ ��������� ��������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (FileStream fs = new FileStream("numbers.txt", FileMode.Truncate, FileAccess.Write))
                {
                    fs.SetLength(0);
                }

                StreamWriter sr = new StreamWriter(@"numbers.txt", true);



                foreach (string t in listBox1.Items)
                {
                    sr.WriteLine(t);
                }

                sr.Dispose();

                MessageBox.Show("�������� ������� ���������!");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�� ������ ��������� ������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Text = "�������� ����� �������";
            label2.Visible = true; button7.Visible = true;
            label3.Visible = true; label4.Visible = true; textBox1.Visible = true; textBox2.Visible = true;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null && textBox2.Text != null)
            {
                string input = textBox1.Text;
                bool isLetters = Regex.IsMatch(input, @"^^[�-��-�]+ [�-��-�]+$");

                if (isLetters)
                {
                    string input2 = textBox2.Text;
                    bool isElevenDigits = Regex.IsMatch(input2, @"^[0-9]{11}$");

                    if (isElevenDigits)
                    {
                        textBox2.Text = FormatPhoneNumber(textBox2.Text);

                        string newContact = textBox1.Text + " " + textBox2.Text;

                        listBox1.Items.Add(newContact);

                        listBox1.Sorted = true;

                        if (MessageBox.Show("������� ��������! ������ ���������� ����������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            textBox1.Text = null;
                            textBox2.Text = null;
                        }
                        else
                        {

                            label2.Text = "������!";
                            label2.Visible = false; button7.Visible = false;
                            label3.Visible = false; label4.Visible = false; textBox1.Visible = false; textBox2.Visible = false;
                        }

                    }
                    else
                    {
                        MessageBox.Show("������� 11 ���� ��� ������!");
                    }
                }
                else
                {
                    string one = textBox1.Text;
                    bool isLetter = Regex.IsMatch(one, @"^[�-��-�]+$");

                    if (isLetter)
                    {
                        string input2 = textBox2.Text;
                        bool isElevenDigits = Regex.IsMatch(input2, @"^[0-9]{11}$");

                        if (isElevenDigits)
                        {
                            textBox2.Text = FormatPhoneNumber(textBox2.Text);

                            string newContact = textBox1.Text + " " + textBox2.Text;

                            listBox1.Items.Add(newContact);

                            listBox1.Sorted = true;

                            if (MessageBox.Show("������� ��������! ������ ���������� ����������?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                textBox1.Text = null;
                                textBox2.Text = null;
                            }
                            else
                            {

                                label2.Text = "������!";
                                label2.Visible = false; button7.Visible = false;
                                label3.Visible = false; label4.Visible = false; textBox1.Visible = false; textBox2.Visible = false;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("��������� ������������ ����� �������!");
                    }
                }
            }
            else
            {
                MessageBox.Show("��������� ����!");
            }
        }
        private string FormatPhoneNumber(string phoneNumber)
        {
            string digitsOnly = new string(phoneNumber.Where(c => char.IsDigit(c)).SkipWhile(c => c == '7').ToArray());

            return digitsOnly.Insert(0, "(").Insert(4, ")").Insert(8, "-").Insert(11, "-");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null && listBox1.Items != null)
            {
                string searchName = textBox1.Text;
                bool isLetters = Regex.IsMatch(searchName, @"^^[�-��-�]+ [�-��-�]+$");

                if (isLetters)
                {
                    int index = listBox1.FindString(searchName);

                    if (index != ListBox.NoMatches)
                    {
                        listBox1.SelectedIndex = index;
                    }

                }
                else
                {
                    bool isLetter = Regex.IsMatch(searchName, @"^[�-��-�]+$");

                    if (isLetter)
                    {
                        for (int i = 0; i < listBox1.Items.Count; i++)
                        {
                            string item = listBox1.Items[i].ToString();

                            if (item.Contains(searchName))
                            {
                                listBox1.SelectedIndex = i;
                                break;

                            }
                          
                        }
                        Thread.Sleep(3000);
                        if (MessageBox.Show("������ ���������� �����?", "������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            textBox1.Text = null;
                        }
                        else
                        {
                            label2.Text = "������!"; label3.Visible = false; label2.Visible = false; textBox1.Visible = false;
                            button8.Visible = false;
                        }
                    }
                }

              
            }
        }
    }
}